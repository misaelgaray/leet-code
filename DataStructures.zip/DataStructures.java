import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Arrays;

public class DataStructures {
    
    public static int maxProfit(int[] prices) {
        // the index and the prince 
        int[] profitStart = {0, prices[0]};
        int[] profitEnd = {0, prices[0]};
        int maxProfit =  0;
        for (int i = 1; i < prices.length; i++) {
            if (prices[i] < profitEnd[1]) {
                if (profitEnd[0] < i) {
                    maxProfit += profitEnd[1] - profitStart[1];
                }
                profitStart[0] = i;
                profitStart[1] = prices[i];
            } else if (prices[i] > profitStart[1]) {
                profitEnd[0] = i;
                profitEnd[1] = prices[i];
            }
        }
        return maxProfit;
    }

    public static String getZone(int row, int column) {
        String[] rowLetter = {"a", "b", "c"};
        int zoneLetterIndex = (int) Math.floor(row/3); 
        int zoneNumber = (int) Math.floor(column/3);
        return rowLetter[zoneLetterIndex] + zoneNumber; 
    }

    public static boolean isValidSudoku(char[][] board) {
        //Row index and numbers(different to .) seen in row
        Map<Integer, Set<String>> seenInRows = new HashMap<>(); 
        //Column index and numbers different to . seen 
        Map<Integer, Set<String>> seenInColumns = new HashMap<>(); 

         Map<String, Set<String>> seenInAreas = new HashMap<>(); 
        
        for (int i = 0; i < board.length; i++) { //Columns
            Set<String> valuesinRow = seenInRows.get(i);
            if (valuesinRow == null) {
                valuesinRow = new HashSet<>();
                seenInRows.put(i, valuesinRow);
            }

            
            for (int j = 0; j < board[i].length; j++) {
                String currentValue = board[i][j] + "";

                if (currentValue.equals(".")) {
                    continue; //Skip empty cells
                }

                String zone = getZone(i, j);
                Set<String> valuesInArea = seenInAreas.get(zone);

                if (valuesInArea == null) {
                    valuesInArea = new HashSet<>();
                    seenInAreas.put(zone, valuesInArea);
                }
                
                if (!valuesInArea.add(currentValue)) {
                    return false;
                }

                // There is no repeated values in the current Row
                if (!valuesinRow.add(currentValue)) {
                    return false;
                }

                Set<String> valuesinColumn = seenInColumns.get(j); // each column
                if (valuesinColumn == null) {
                    valuesinColumn = new HashSet<>();
                    seenInColumns.put(j, valuesinColumn);
                }
                //There is no repeated values in the columns
                if (!valuesinColumn.add(currentValue)) {
                    return false;
                }

            }
        }

        return true;
    }

    public static List<Integer> spiralOrder(int[][] matrix) {
        
        Integer top = 0;
        Integer bottom = matrix.length - 1;
        Integer left = 0;
        Integer right = matrix[0].length - 1;

        List<Integer> output = new ArrayList<>();

        while (left <= right && top <= bottom) {
         
            for(int i = left; i <= right; i++) {
               output.add(matrix[top][i]);
            }
            top++;
            
           
            for(int i = top; i <= bottom; i++) {
                output.add(matrix[i][right]);
            }
            right--;
            
            if (top <= bottom) {
                for(int i = right; i >= left; i--) {
                    output.add(matrix[bottom][i]);
                }
                bottom--;
            }
           

            if (left <= right) {
                for (int i = bottom; i >= top; i--) {
                    output.add(matrix[i][left]);
                }
                left++;
            }
        }

        return output;
    }

    public static int[][] generateMatrix(int n) {
        int[][] matrix = new int[n][n];
        int num = 1;
        int left = 0, right = matrix[0].length - 1, top = 0, bottom = matrix.length - 1;
        while(num <= n*n) {
            for (int i = left; i <= right; i++) {
                matrix[top][i] = num++;
            }
            top++;

            for (int i = top; i <= bottom; i++) {
                matrix[i][right] = num++;
            }
            right--;
            
            if (top <= bottom) {
                for(int i = right; i >= left; i--) {
                    matrix[bottom][i] = num++;
                }
                bottom--;
            }

            if (left <= right) {
                for (int i = bottom; i >= top; i--) {
                    matrix[i][left] = num++;
                }
                left++;
            }
        }
        return matrix;
    }

    public static void rotate(int[] nums, int k) {
        int secondIndex = k;
        for (int i = 0; i < nums.length - k; i++) {
            int currentVal = nums[i];
            nums[i] = nums[nums.length - secondIndex];
            nums[nums.length - secondIndex - 1] = currentVal;
            secondIndex--;
        }
        System.out.print("Rotated Array: " + java.util.Arrays.toString(nums));
    }
    //{{1,2,3},{4,5,6},{7,8,9}}
    public static void rotateInPlace(int[][] matrix) {
        int n = matrix.length;
        for(int i = 0; i < matrix.length / 2; i++) {
            for (int j = i; j < (matrix[i].length - 1 - i); j++) {
                int topLeft = matrix[i][j];
                matrix[i][j] =  matrix[(n - 1 - i)-(j - i)][i];
                matrix[(n - 1 - i)-(j - i)][i] =  matrix[n - 1 - i][(n - 1 - i)-(j - i)];
                matrix[n - 1 - i][(n - 1 - i)-(j - i)] = matrix[j][n - 1 - i];
                matrix[j][n -1 - i] = topLeft;
               
            }
        }
        System.out.println("Rotated Matrix" + Arrays.deepToString(matrix));
    }

    public static void rotateV2(int[][] matrix) {
        int left = 0, right = matrix.length - 1;
        int top = 0, bottom = matrix.length - 1;

        while (left < right) {
            for (int i = left; i < (right - left); i++ ) {
                int topLeft = matrix[top][left + i];
                matrix[top][left + i] = matrix[bottom - i][left];
                matrix[bottom - i][left] = matrix[bottom][right - i];
                matrix[bottom][right - i] = matrix[top + i][right];
                matrix[top + i][right] = topLeft; 
            }
            left++;
            right--;
            top++;
            bottom--;
        }
        System.out.println("Rotated Matrix" + Arrays.deepToString(matrix));
    }

    public static void rotateWithSpace(int[][] matrix) {
        int n = matrix.length;
        int [][] rotatedMatrix = new int[n][n];
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                rotatedMatrix[j][n - 1 - i] = matrix[i][j];
            }
        }
         System.out.println("Rotated Matrix" + Arrays.deepToString(rotatedMatrix));
    }

    public static List<Integer> findDiagonalOrder(int [][]matrix) {
        List<Integer> rows = new ArrayList<>();
        int y = matrix.length;
        int x = matrix[0].length;

        boolean goingUp = true;

        int row = 0;
        int column = 0;
        while (rows.size() < (y * x)) {
            if (goingUp) {
                while (row >= 0 && column < x) {
                    rows.add(matrix[row][column]);
                    column++;
                    row--;
                }
                if (column == x) {
                    column -= 1;
                    row += 2;
                } else {
                    row += 1;
                }
                goingUp = false;
            } else {
                while (row < y && column >= 0) {
                    rows.add(matrix[row][column]);
                    row++;
                    column--;
                }
                if (row == y) {
                    row -= 1;
                    column += 2;
                } else {
                    column += 1;
                }
                goingUp = true;
            }
        }
        // Convert List<Integer> to int[]
        int[] result = new int[rows.size()];
        for (int i = 0; i < rows.size(); i++) {
            result[i] = rows.get(i);
        }
        return result;
    }

    public int[] findDiagonalOrderV2(int[][] mat) {
        int m = mat.length;
       
        int n = mat[0].length;

        int[] res = new int[m * n];
        int i = 0, j = 0, idx = 0;
        boolean up = true; // moving up-right when true, down-left when false

        while (idx < m * n) {
            res[idx++] = mat[i][j];

            if (up) {
                // Try to go up-right
                if (j == n - 1) {        // hit right boundary, go down and flip
                    i++;
                    up = false;
                } else if (i == 0) {     // hit top boundary, go right and flip
                    j++;
                    up = false;
                } else {                 // normal move
                    i--;
                    j++;
                }
            } else {
                // Try to go down-left
                if (i == m - 1) {        // hit bottom boundary, go right and flip
                    j++;
                    up = true;
                } else if (j == 0) {     // hit left boundary, go down and flip
                    i++;
                    up = true;
                } else {                 // normal move
                    i++;
                    j--;
                }
            }
        }
        return res;
    }


    public static int[][] matrixReshape(int[][] mat, int r, int c) {
        int [][] reshaped = new int[r][c];

        if (r == mat.length && c == mat[0].length ||  r * c < mat.length * mat[0].length) {
            return mat;
        }

        if (r * c > mat.length * mat[0].length) {
            return mat;
        }

        int row = 0, column = 0;
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                reshaped[row][column] = mat[i][j];
                column++;
                if (column == c) {
                    column = 0;
                    row++;
                }
            }
        }
        return reshaped;
    }

    //O(m*n)
    public static boolean isToeplitzMatrix(int[][] matrix) {
        int rows = matrix.length;
        int cols = matrix[0].length ;
        for(int i = 0; i < cols; i++ ) {
            int tempI = 0;
            int tempJ = i;
            int val = matrix[tempI][tempJ];
            while (tempI < rows && tempJ < cols ) {
                if (val != matrix[tempI][tempJ]) {
                    return false;
                }
                tempI++;
                tempJ++;
            }
        }

        for(int i = 0; i < rows; i++ ) {
            int tempI = i;
            int tempJ = 0;
            int val = matrix[tempI][tempJ];
            while (tempI < rows && tempJ < cols ) {
                if (val != matrix[tempI][tempJ]) {
                    return false;
                }
                tempI++;
                tempJ++;
            }
        }

        return true;
    }


    public static int largestOverlap(int[][] img1, int[][] img2) {
        //Store the position where the value is 1
        List<Integer[]> overlapsImg1 = new ArrayList<>(); //[{0,1}, {1,0}]
        List<Integer[]> overlapsImg2 = new ArrayList<>();
        for(int i = 0; i < img1.length; i++) {
            for(int j = 0; j < img1[i].length; j++) {
                if (img1[i][j] == 1) {
                    overlapsImg1.add(new int[]{i, j});
                }
                if (img2[i][j] == 1) {
                    overlapsImg2.add(new int[]{i, j});
                }
            }
        }

        Map<String, Integer> overlapTimes = new HashMap<>();
        for (int i = 0; i < overlapsImg1.size(); i++) {
            Integer[] position1 = overlapsImg1.get(i);
            for (int j = 0; j < overlapsImg2.size(); j++) {
                Integer[] position2 = overlapsImg2.get(j);
                String crossPosition = (position2[0] - position1[0]) + "," + (position2[1] - position1[1]);
                Integer timesInOperation = overlapTimes.get(crossPosition);
                if (timesInOperation == null) {
                    overlapTimes.put(crossPosition, 1);
                } else {
                    timesInOperation++;
                    overlapTimes.put(crossPosition, timesInOperation);
                }
            }
        }

        int maxOverlap = 0;
        for (int count : overlapTimes.values()) {
            if (count > maxOverlap) {
                maxOverlap = count;
            }
        }

        return maxOverlap;
    }
    
   
    public static void main(String[] args) {
        // int[] prices = { 7,1,5,3,6,4};
        // int result = maxProfit(prices);
        // System.out.println("Maximum Profit: " + result);

        // int[] nums = {1,2,3,4,5,6,7};
        // int k = 3;
        // rotate(nums, k);

        // char[][] board = {
        //     {'5', '3', '.', '.', '7', '.', '.', '.', '.'},
        //     {'6', '.', '.', '1', '9', '5', '.', '.', '.'},
        //     {'.', '9', '8', '.', '.', '.', '.', '6', '.'},
        //     {'8', '.', '.', '.', '6', '.', '.', '.', '3'},
        //     {'4', '.', '6', '8', '.', '3', '.', '.', '1'},
        //     {'7', '.', '.', '2', '.', '.', '.', '.', '.'},
        //     {'.', '6', '.', '.', '.', '.', '2', '8', '.'},
        //     {'.', '.', '.', '4', '1', '9', '.', '.', '5'},
        //     {'.', '.', '.', '.', '8', '.', '.', '7', '9'}
        // };
        // boolean isValid = isValidSudoku(board);
        // System.out.println("Is the Sudoku valid? " + isValid);

        // int matrix[][] = {
        //     {1,2,3,4},
        //     {5,6,7,8},
        //     {9,10,11,12}
        // };
        // List<Integer> spiral = spiralOrder(matrix);
        // System.out.println("Spiral Order: " + spiral);

        // int[][] generatedMatrix = generateMatrix(3);
        // System.out.println("Generated Matrix: " + java.util.Arrays.deepToString(generatedMatrix));

        int[][] matrix = {{1,2,3},{4,5,6},{7,8,9}};
        //rotateInPlace(matrix);
        //rotateWithSpace(matrix);
        //rotateV2(matrix);
        // List<Integer> result = findDiagonalOrder(matrix);
        // System.out.println("REsult" + result);

        // int[][] reshapedMatrix = matrixReshape(matrix, 2, 5);
        // System.out.println(Arrays.deepToString(reshapedMatrix));


        // int[][] matrixTapiz = {{1,2,3,4},{5,1,2,3},{9,5,1,2}};

        // System.out.println(isToeplitzMatrix(matrixTapiz));
    }
}